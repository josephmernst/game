/* Copyright (c) Mark J. Kilgard, 1997, 1998. */

/* This program is freely distributable without licensing fees
   and is provided without guarantee or warrantee expressed or
   implied. This program is -not- in the public domain. */

/* Takeshi Hakamata <tkh@cs.unm.edu>
   Implemented joystick support under Linux */

#ifdef _WIN32
#include <windows.h>
#include <mmsystem.h>  /* Win32 Multimedia API header. */
#endif
#ifdef LINUX_JOYSTICK
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/joystick.h>
#endif /* LINUX_JOYSTICK */

#include "glutint.h"

#ifdef LINUX_JOYSTICK

#define JOYSTICK_DRIVER_QUEUE_LEN       64
#define JOYSTICK_EVENT_NOT_PROCESSED	0
#define JOYSTICK_EVENT_PROCESSED	1

#endif /* LINUX_JOYSTICK */

GLUTjoystick *__glutJoystick = NULL;

#ifdef LINUX_JOYSTICK

static void
probeJoystick(void)
{
  ioctl(__glutJoystick->fd, JSIOCGAXES, &__glutJoystick->numAxes);
  ioctl(__glutJoystick->fd, JSIOCGBUTTONS, &__glutJoystick->numButtons);
}

static void
processEvent(struct js_event *event)
{
  switch (event->type) {
  case JS_EVENT_BUTTON:
  case (JS_EVENT_INIT | JS_EVENT_BUTTON):
    if (event->value) {
      // A button is pressed.
      __glutJoystick->buttonsState |= (1 << event->number);
    } else {
      // A button is released.
      __glutJoystick->buttonsState &= ~(1 << event->number);
    }
    break;

  case JS_EVENT_AXIS:
  case (JS_EVENT_INIT | JS_EVENT_AXIS):
    __glutJoystick->axes[event->number] = event->value;
    break;

  default:
    __glutWarning("got unknown event.");
    break;
  }
}

/* 
 * Returns 1 if a joystick event is processed, otherwise returns 0.
 */
int
readJoystick()
{
    int readCount;
#if 0
    struct js_event event;
#else
    struct js_event events[JOYSTICK_DRIVER_QUEUE_LEN];
#endif

    if (!__glutJoystick || !__glutCurrentWindow->joystick)
    {
	return 0;
    }

    if ((readCount = read(__glutJoystick->fd, &events, sizeof(events)))
	> 0) {
	// offset points to the latest event in the driver queue.
	int offset = readCount / sizeof(struct js_event) - 1;
	processEvent(&events[offset]);
	return 1;
    }

    if (errno != EAGAIN) {
        //__glutWarning("error reading data from joystick.");
        return 0;
    }

    return 1;
}

int
processJoystickEvent(void)
{
/* This will match the range to same as Win32. */
#define SCALE(x)  ((x) / 32)
//  if (readJoystick() == JOYSTICK_EVENT_PROCESSED)
  {
    __glutCurrentWindow->joystick(__glutJoystick->buttonsState,
			    	  SCALE(__glutJoystick->axes[0]),
			    	  SCALE(__glutJoystick->axes[1]),
			    	  SCALE(__glutJoystick->axes[2]));
  }
}

void
__glutPollJoystick(void)
{
  // Use polling time to avoid the latency problem.
  if (__glutJoystick && __glutJoystick->fd && __glutCurrentWindow->joystick) {
    struct timeval now, elapsed;

    GETTIMEOFDAY(&now);
    TIMEDELTA(elapsed, now, __glutCurrentWindow->joyLastPollTime);
    
    // Poll joystick.
    // ASSUMPTION: poll interval is given in msec.
    if (__glutCurrentWindow->joyPollInterval <=
	(elapsed.tv_sec * 1000 + elapsed.tv_usec / 1000)) {

      // If joystick is not read, just return.
      if (!readJoystick()) {
	//__glutWarning("didn't process joystick event.\n");
	return;
      }

      processJoystickEvent();
      //GETTIMEOFDAY(&__glutCurrentWindow->joyLastPollTime);
      __glutCurrentWindow->joyLastPollTime = now;
    }
  }
}

void APIENTRY
glutInitJoystick(const char *joystickDevice)
{
  int i;

  __glutJoystick = (GLUTjoystick *) malloc(sizeof(GLUTjoystick));

  if (!__glutJoystick)
    __glutFatalError("out of memory.");

  memset(__glutJoystick, 0, sizeof(GLUTjoystick));

  __glutJoystick->fd = open(joystickDevice, O_RDONLY | O_NONBLOCK);

  if (__glutJoystick->fd < 0) {
    __glutWarning("failed to open joystick device %s.", joystickDevice);
    free(__glutJoystick);
    __glutJoystick = NULL;

    return;
  }

  for(i = 0; i < MAX_JOYSTICK_AXES_NUM; i++) {
    __glutJoystick->axes[i] = 0;
  }

  __glutJoystick->buttonsState = 0;

  probeJoystick();
}

#endif /* LINUX_JOYSTICK */

/* CENTRY */
void APIENTRY
glutJoystickFunc(GLUTjoystickCB joystickFunc, int pollInterval)
{
#ifdef _WIN32
  if (joystickFunc && (pollInterval > 0)) {
    if (__glutCurrentWindow->entryState == WM_SETFOCUS) {
      MMRESULT result;

      /* Capture joystick focus if current window has
  	 focus now. */
      result = joySetCapture(__glutCurrentWindow->win,
        JOYSTICKID1, 0, TRUE);
      if (result == JOYERR_NOERROR) {
        (void) joySetThreshold(JOYSTICKID1, pollInterval);
      }
    }
    __glutCurrentWindow->joyPollInterval = pollInterval;
  } else {
    /* Release joystick focus if current window has
       focus now. */
    if (__glutCurrentWindow->joystick
      && (__glutCurrentWindow->joyPollInterval > 0)
      && (__glutCurrentWindow->entryState == WM_SETFOCUS)) {
      (void) joyReleaseCapture(JOYSTICKID1);
    }
    __glutCurrentWindow->joyPollInterval = 0;
  }
  __glutCurrentWindow->joystick = joystickFunc;
#else
  if (joystickFunc && (pollInterval > 0)) {
    __glutCurrentWindow->joystick = joystickFunc;
    __glutCurrentWindow->joyPollInterval = pollInterval;
  } else {
    __glutCurrentWindow->joystick = NULL;
    __glutCurrentWindow->joyPollInterval = 0;
  }

  /* Reset the last poll time to 0. */
  __glutCurrentWindow->joyLastPollTime.tv_sec = 0;
  __glutCurrentWindow->joyLastPollTime.tv_usec = 0;
#endif
}

void APIENTRY
glutForceJoystickFunc(void)
{
#ifdef _WIN32
  if (__glutCurrentWindow->joystick) {
    JOYINFOEX jix;
    MMRESULT res;
    int x, y, z;

    /* Poll the joystick. */
    jix.dwSize = sizeof(jix);
    jix.dwFlags = JOY_RETURNALL;
    res = joyGetPosEx(JOYSTICKID1,&jix);
    if (res == JOYERR_NOERROR) {

      /* Convert to int for scaling. */
      x = jix.dwXpos;
      y = jix.dwYpos;
      z = jix.dwZpos;

#define SCALE(v)  ((int) ((v - 32767)/32.768))

      __glutCurrentWindow->joystick(jix.dwButtons,
        SCALE(x), SCALE(y), SCALE(z));
    }
  }
#endif
#ifdef LINUX_JOYSTICK
  // If joystick is not read, just return.
  if (!readJoystick()) {
    //__glutWarning("didn't process joystick event.\n");
      return;
  }

  processJoystickEvent();
  GETTIMEOFDAY(&__glutCurrentWindow->joyLastPollTime);
  processJoystickEvent();
#endif /* LINUX_JOYSTICK */
}


/* ENDCENTRY */
