/* Copyright (c) Mark J. Kilgard, 1997. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>

typedef struct {
    float v[3];
    int   buttons[5];
} JoystickState;

static JoystickState joyState;
const  float accelFactor = 0.001f;
static float x = 0.0f;
static float y = 0.0f;
static float z = 0.0f;

const float mat[5][3] = {
  {1.0f, 0.0f, 0.0f},
  {0.0f, 1.0f, 0.0f},
  {0.0f, 0.0f, 1.0f},
  {1.0f, 0.0f, 1.0f},
  {0.0f, 1.0f, 1.0f},
};


void
joystick(unsigned int buttonMask, int x, int y, int z)
{
  int axes[3] = {x, y, z};
  int i;

  for (i = 0; i < 3; i++) {
    if (axes[i] >= 30 && axes[i] <= 32) {
      joyState.v[i] = 0.0f;
    } else {
      joyState.v[i] = axes[i] / 32.0f - 1.0f;
    }
  }

  for (i = 0; i < 5; i++) {
    joyState.buttons[i] = (buttonMask >> i) & 0x1;
  }

  glutPostRedisplay();

#if 0
  fprintf(stderr, "joy_test: joy 0x%x, axis[0]=%d axis[1]=%d axis[2]=%d\n",
	  buttonMask, axes[0], axes[1], axes[2]);
#endif
}

void
joyPoll(void)
{
  printf("force\n");
  glutForceJoystickFunc();
}

void
menu(int value)
{
  switch(value) {
  case 1:
    glutJoystickFunc(joystick, 100);
    glutIdleFunc(NULL);
    break;
  case 2:
    glutJoystickFunc(NULL, 0);
    glutIdleFunc(NULL);
    break;
  case 3:
    glutJoystickFunc(joystick, 0);
    glutIdleFunc(joyPoll);
    break;
  }
}

void
display(void)
{
  int i;

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  x += joyState.v[0] * accelFactor;
  y += joyState.v[1] * accelFactor;
  z += joyState.v[2] * accelFactor;

  glLoadIdentity();
  glTranslatef(0.0f, 0.0f, -10.0f);
  glTranslatef(x, y, z);

  for (i = 0; i < 5; i++) {
    if (joyState.buttons[i]) {
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat[i]);
    }
  }

  glPushMatrix();
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glTranslatef(0.0f, 0.0f, -1.0f);
  glutSolidTeapot(1.0);
  glPopMatrix();

  glutSwapBuffers();
}

void
keyboard(unsigned char c, int x, int y)
{
  if (c == 27) exit(0);
}

void
initOGL(void)
{
  glClearColor(0.0, 0.0, 0.0, 0.0);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(45.0f, 1.0f, 0.01f, 100.0f);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  glEnable(GL_DEPTH_TEST);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
}

int
main(int argc, char **argv)
{
  memset(&joyState, 0, sizeof(JoystickState));

  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE);
  glutInitWindowSize(512, 512);
  // XXXtkh
  // For Linux joystick, we need to call glutInitJoystick().
  glutInitJoystick("/dev/input/js0");
  glutCreateWindow("joystick test");

  initOGL();

  glutDisplayFunc(display);
  glutKeyboardFunc(keyboard);
  glutCreateMenu(menu);
  glutAddMenuEntry("Enable joystick callback", 1);
  glutAddMenuEntry("Disable joystick callback", 2);
  glutAddMenuEntry("Force joystick polling", 3);
  glutAttachMenu(GLUT_RIGHT_BUTTON);

  glutMainLoop();
  return 0;             /* ANSI C requires main to return int. */
}
